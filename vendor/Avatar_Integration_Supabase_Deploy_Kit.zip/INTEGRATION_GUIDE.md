# Integration Guide
How to wire ChatDock and Supabase.
